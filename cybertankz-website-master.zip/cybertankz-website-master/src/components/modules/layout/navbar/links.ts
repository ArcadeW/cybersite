export const links=[
    {
        title: "Home",
        url: "/"
    },
    {
        title: "Rules",
        url: "/"
    },
    {
        title: "Forum",
        url: "https://www.cybertankzforum.com/"
    },
    {
        title: "Wiki",
        url: ""
    },
    {
        title: "eSports",
        url: ""
    },
]